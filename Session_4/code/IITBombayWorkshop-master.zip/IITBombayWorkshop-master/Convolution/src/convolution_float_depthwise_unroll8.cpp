#include"Convolution.h"

void Convolution::convolution_float_depthwise_unroll8(ConvParams conv_params)
{
  double *out_ptr = float_outputs;
  int32_t remain_nodes = conv_params.nodes;
  double *weights_ptr = float_weights;
  double *inp_ptr = float_inputs;
  double *weights_ptr_base = weights_ptr, *kernel_ptr;
  int32_t row_idx, col_idx;
  int out_depth = conv_params.nodes;
  int inp_depth = conv_params.inp_d;
  int kernel_h = conv_params.ker_h;
  int kernel_w = conv_params.ker_w;
  int dilation_h = conv_params.dil_h;
  int dilation_w = conv_params.dil_w;
  int inp_next_row_offset = conv_params.inp_w;
  int conv_inp_depth = conv_params.inp_d;
  for (row_idx = 0; row_idx < conv_params.out_h; ++row_idx)
  {
    for (col_idx = 0; col_idx < conv_params.out_w; ++col_idx)
    {
      //setting starting location of the input window          
      int32_t inp_col_idx = col_idx * conv_params.str_w;
      int32_t inp_row_idx = row_idx * conv_params.str_h;
      double *optr = out_ptr
        + ((row_idx * conv_params.out_w + col_idx) * out_depth);
      double *iptr_w = inp_ptr
        + ((inp_row_idx * conv_params.inp_w + inp_col_idx)
        * inp_depth);
      int32_t node_idx;
      kernel_ptr = weights_ptr_base;
      for (node_idx = 0; node_idx < remain_nodes; node_idx++)
      {
        double out_val = 0;
        int32_t k_row_index, k_col_index, ch_idx;
        for (k_row_index = 0; k_row_index < kernel_h; ++k_row_index)
        {
          double *iptr = NULL;
          iptr = iptr_w
            + ((k_row_index * dilation_h * inp_next_row_offset)
            * inp_depth);
          for (k_col_index = 0; k_col_index < kernel_w; ++k_col_index)
          {
            int conv_inp_depth_loop_unroll = 8 * (conv_inp_depth / 8);

            for (ch_idx = 0; ch_idx < conv_inp_depth_loop_unroll; ch_idx += 8)
            {
              out_val += kernel_ptr[((k_row_index * kernel_w + k_col_index)
                * conv_inp_depth) + ch_idx]
                * iptr[((dilation_w * k_col_index) * inp_depth)
                + ch_idx];

              out_val += kernel_ptr[((k_row_index * kernel_w + k_col_index)
                * conv_inp_depth) + (ch_idx + 1)]
                * iptr[((dilation_w * k_col_index) * inp_depth)
                + (ch_idx + 1)];

              out_val += kernel_ptr[((k_row_index * kernel_w + k_col_index)
                * conv_inp_depth) + (ch_idx + 2)]
                * iptr[((dilation_w * k_col_index) * inp_depth)
                + (ch_idx + 2)];

              out_val += kernel_ptr[((k_row_index * kernel_w + k_col_index)
                * conv_inp_depth) + (ch_idx + 3)]
                * iptr[((dilation_w * k_col_index) * inp_depth)
                + (ch_idx + 3)];

              out_val += kernel_ptr[((k_row_index * kernel_w + k_col_index)
                * conv_inp_depth) + (ch_idx + 4)]
                * iptr[((dilation_w * k_col_index) * inp_depth)
                + (ch_idx + 4)];

              out_val += kernel_ptr[((k_row_index * kernel_w + k_col_index)
                * conv_inp_depth) + (ch_idx + 5)]
                * iptr[((dilation_w * k_col_index) * inp_depth)
                + (ch_idx + 5)];

              out_val += kernel_ptr[((k_row_index * kernel_w + k_col_index)
                * conv_inp_depth) + (ch_idx + 6)]
                * iptr[((dilation_w * k_col_index) * inp_depth)
                + (ch_idx + 6)];

              out_val += kernel_ptr[((k_row_index * kernel_w + k_col_index)
                * conv_inp_depth) + (ch_idx + 7)]
                * iptr[((dilation_w * k_col_index) * inp_depth)
                + (ch_idx + 7)];
            }
          }
        }

        // BiasAdd 
        int32_t bias_node0;
        if (biases != NULL)
        {
          bias_node0 = (biases[node_idx]);
          out_val = (int32_t)(((bias_node0)
            +(((int64_t)out_val))));
        }

        // ReLU 
        if (flag_relu)
        {
          out_val = out_val > 0 ? out_val : 0;
        }
        *optr++ = out_val;
        kernel_ptr += (conv_inp_depth * kernel_w * kernel_h);
      }
    }
  }
}