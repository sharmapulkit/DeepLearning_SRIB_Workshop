#include"Convolution.h"

void Convolution::convolution_float_depthwise_kernel_reuse_unroll8(ConvParams conv_params)
{
  double *out_ptr = float_outputs;
  int32_t nodes = conv_params.nodes, remain_w;
  double *weights_ptr = float_weights;
  double *inp_ptr = float_inputs;
  double *weights_ptr_base = weights_ptr, *kernel_ptr;
  int32_t row_idx, col_idx;
  int out_depth = conv_params.nodes;
  int inp_depth = conv_params.inp_d;
  int kernel_h = conv_params.ker_h;
  int kernel_w = conv_params.ker_w;
  int dilation_h = conv_params.dil_h;
  int dilation_w = conv_params.dil_w;
  int inp_next_row_offset = conv_params.inp_w;
  int conv_inp_depth = conv_params.inp_d;
  //printf("%p\n", out_ptr);
  for (row_idx = 0; row_idx < conv_params.out_h; ++row_idx)
  {
    for (col_idx = 0; col_idx < conv_params.out_w; col_idx += kernel_reuse_amt)
    {
      //setting starting location of the input window          
      int32_t inp_col_idx = col_idx * conv_params.str_w;
      int32_t inp_row_idx = row_idx * conv_params.str_h;
      double *optr = out_ptr
        + ((row_idx * conv_params.out_w + col_idx) * out_depth);
      double *iptr_w = inp_ptr
        + ((inp_row_idx * conv_params.inp_w + inp_col_idx)
        * inp_depth);
      int32_t node_idx;
      remain_w = MIN((conv_params.out_w - col_idx), kernel_reuse_amt);
      for (node_idx = 0; node_idx < nodes; ++node_idx)
      {
        int32_t out_val = 0;
        kernel_ptr = weights_ptr_base + node_idx * inp_depth * kernel_h * kernel_w;
        int32_t k_row_index, k_col_index, ch_idx;
        for (k_row_index = 0; k_row_index < kernel_h; ++k_row_index)
        {
          double *iptr = NULL;
          iptr = iptr_w
            + ((k_row_index * dilation_h * inp_next_row_offset)
            * inp_depth);
          for (k_col_index = 0; k_col_index < kernel_w; ++k_col_index)
          {
            for (ch_idx = 0; ch_idx < conv_inp_depth; ch_idx++)
            {
              int16_t ker_val = kernel_ptr[k_row_index * kernel_w * inp_depth + k_col_index * inp_depth + ch_idx];
              int32_t remain_w2 = 8 * (remain_w / 8);
              int col_id;
              for (col_id = 0; col_id < remain_w2; col_id += 8){
                optr[col_id * out_depth + node_idx] += ker_val * iptr[col_id * inp_depth + ch_idx];
                optr[(col_id + 1)* out_depth + node_idx] += ker_val * iptr[(col_id + 1)* inp_depth + ch_idx];
                optr[(col_id + 2)* out_depth + node_idx] += ker_val * iptr[(col_id + 2)* inp_depth + ch_idx];
                optr[(col_id + 3)* out_depth + node_idx] += ker_val * iptr[(col_id + 3)* inp_depth + ch_idx];
                optr[(col_id + 4)* out_depth + node_idx] += ker_val * iptr[(col_id + 4)* inp_depth + ch_idx];
                optr[(col_id + 5)* out_depth + node_idx] += ker_val * iptr[(col_id + 5)* inp_depth + ch_idx];
                optr[(col_id + 6)* out_depth + node_idx] += ker_val * iptr[(col_id + 6)* inp_depth + ch_idx];
                optr[(col_id + 7)* out_depth + node_idx] += ker_val * iptr[(col_id + 7)* inp_depth + ch_idx];
              }
              // col_id -= 8;
              for (; col_id < remain_w; col_id++){
                optr[col_id * out_depth + node_idx] += ker_val * iptr[col_id * inp_depth + ch_idx];
              }
            }
          }
        }

        // BiasAdd 
        int32_t bias_node0;
        if (biases != NULL)
        {
          bias_node0 = (biases[node_idx]);
          for (int col_id = col_idx; col_id < remain_w; ++col_id){
            optr[col_id * out_depth + node_idx] += (int32_t)(((bias_node0)
              +(((int64_t)out_val))));
          }
        }
#if 0
        // ReLU 
        if (flag_relu)
        {
          out_val = out_val > 0 ? out_val : 0;
        }
        *optr++ = out_val;
#endif
        //kernel_ptr += (conv_inp_depth * kernel_w * kernel_h);
      }
    }
  }
}