#include<iostream>
#include<cstdint>
using namespace std;

#include "Headers.h"

#define MIN(a,b) a < b ? a : b

class Convolution
{
private:
  ConvParams conv_params;
  ConvControlParams conv_control_params;

  double *float_weights;
  double *float_inputs;
  double *float_biases;
  double *float_outputs;

  int16_t *weights;
  int16_t *inputs;
  int32_t *biases;
  int32_t *outputs;
  int8_t flag_relu;
  int bias_sh_fac = 0;
  int out_sh_fac = 2;

  int input_reuse_amt = 8;
  int kernel_reuse_amt = 8;

  
public:
  Convolution(){}
  ~Convolution(){}

  //add parameters
  void init();
  void set_conv_params(ConvParams conv_params_val);
  void set_conv_control_params(ConvControlParams conv_control_params);
  double run_convolution();

private:
  void set_output_sizes(ConvParams *conv_params);
  void populate_inputs_params(ConvParams conv_params);
  void initialize_outputs(void *out, int size);
  void initialize_int16(int16_t *mem, int size);
  void initialize_int32(int32_t *mem, int size);
  void initialize_float(double *mem, int size);

  //! Combination with fixed
  void convolution_fixed_depthwise(ConvParams conv_params);                               //done
  void convolution_fixed_planar(ConvParams conv_params);                                  //done
  
  //! Combination with fixed depthwise
  void convolution_fixed_depthwise_input_reuse(ConvParams conv_params);                   //done 
  void convolution_fixed_depthwise_kernel_reuse(ConvParams conv_params);                  //done 
  
  void convolution_fixed_depthwise_unroll2(ConvParams conv_params);                       //done
  void convolution_fixed_depthwise_unroll4(ConvParams conv_params);                       //done
  void convolution_fixed_depthwise_unroll8(ConvParams conv_params);                       //done
  void convolution_fixed_depthwise_unroll16(ConvParams conv_params);                      //done

  //! Combination with fixed depthwise input_reuse
  void convolution_fixed_depthwise_input_reuse_unroll2(ConvParams conv_params);           //done
  void convolution_fixed_depthwise_input_reuse_unroll4(ConvParams conv_params);           //done
  void convolution_fixed_depthwise_input_reuse_unroll8(ConvParams conv_params);           //done
  void convolution_fixed_depthwise_input_reuse_unroll16(ConvParams conv_params);          //done

  //! Combination with fixed depthwise kernel_reuse
  void convolution_fixed_depthwise_kernel_reuse_unroll2(ConvParams conv_params);          //done
  void convolution_fixed_depthwise_kernel_reuse_unroll4(ConvParams conv_params);          //done
  void convolution_fixed_depthwise_kernel_reuse_unroll8(ConvParams conv_params);          //done
  void convolution_fixed_depthwise_kernel_reuse_unroll16(ConvParams conv_params);         //done
 

  //! Combination with fixed planar
                                                                                          
  void convolution_fixed_planar_unroll2(ConvParams conv_params);                          //done
  void convolution_fixed_planar_unroll4(ConvParams conv_params);                          //done
  void convolution_fixed_planar_unroll8(ConvParams conv_params);                          //done
  void convolution_fixed_planar_unroll16(ConvParams conv_params);                         //done
  ////////////////////////////////////////////////////////////////////////////////////////////////////

  //! Combination with float
  void convolution_float_depthwise(ConvParams conv_params);                               //done
  void convolution_float_planar(ConvParams conv_params);                                  //done

  //! Combination with float depthwise
  void convolution_float_depthwise_input_reuse(ConvParams conv_params);                   //done
  void convolution_float_depthwise_kernel_reuse(ConvParams conv_params);                  //done
                   
  void convolution_float_depthwise_unroll2(ConvParams conv_params);                       //done
  void convolution_float_depthwise_unroll4(ConvParams conv_params);                       //done
  void convolution_float_depthwise_unroll8(ConvParams conv_params);                       //done
  void convolution_float_depthwise_unroll16(ConvParams conv_params);                      //done

  //! Combination with fixed depthwise input_reuse
  void convolution_float_depthwise_input_reuse_unroll2(ConvParams conv_params);           //done
  void convolution_float_depthwise_input_reuse_unroll4(ConvParams conv_params);           //done
  void convolution_float_depthwise_input_reuse_unroll8(ConvParams conv_params);           //done
  void convolution_float_depthwise_input_reuse_unroll16(ConvParams conv_params);          //done

  //! Combination with fixed depthwise kernel_reuse
  void convolution_float_depthwise_kernel_reuse_unroll2(ConvParams conv_params);          //done
  void convolution_float_depthwise_kernel_reuse_unroll4(ConvParams conv_params);          //done
  void convolution_float_depthwise_kernel_reuse_unroll8(ConvParams conv_params);          //done
  void convolution_float_depthwise_kernel_reuse_unroll16(ConvParams conv_params);         //done

  //! Combination with fixed planar

  void convolution_float_planar_unroll2(ConvParams conv_params);                          //done
  void convolution_float_planar_unroll4(ConvParams conv_params);                          //done
  void convolution_float_planar_unroll8(ConvParams conv_params);                          //done
  void convolution_float_planar_unroll16(ConvParams conv_params);                         //done
};