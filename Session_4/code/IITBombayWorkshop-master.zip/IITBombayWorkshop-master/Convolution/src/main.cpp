#include "Convolution.h"
#include <ctime>

#define INP_H 32
#define INP_W 32
#define INP_D 64
#define KER_H 3
#define KER_W 3
#define NODES 128
#define STR_H 1
#define STR_W 1
#define PAD_H 0
#define PAD_W 0

void init_conv_params(ConvParams *conv_params);
void init_conv_control_params(ConvControlParams *conv_control_params);

int main()
{
//#if 0
  Convolution conv;

  double conv_duration;

  ConvParams conv_params;
  ConvControlParams conv_control_params;

  //Fixed point tests

  //Float point tests
  cout << "Fixed point cases:" << endl;

  conv_control_params.fixed_float = eFloat;
  conv_control_params.data_access = eDepthwiseKernelReuse;

  //Case1:
  //conv_control_params.fixed_float = eFloat;
  //conv_control_params.data_access = eDepthwiseOnly;
  conv_control_params.loop_unroll = eNoLoopUnroll;
  //init_conv_control_params(&conv_control_params);
  init_conv_params(&conv_params);
  conv.set_conv_control_params(conv_control_params);
  conv.set_conv_params(conv_params);
  conv_duration = conv.run_convolution();
  cout << "The conv duration is: " << conv_duration << endl;

  //Case2:
  //conv_control_params.fixed_float = eFloat;
  //conv_control_params.data_access = eDepthwiseOnly;
  conv_control_params.loop_unroll = eLoopUnroll2;
  //init_conv_control_params(&conv_control_params);
  init_conv_params(&conv_params);
  conv.set_conv_control_params(conv_control_params);
  conv.set_conv_params(conv_params);
  conv_duration = conv.run_convolution();
  cout << "The conv duration is: " << conv_duration << endl;

  //Case3:
  //conv_control_params.fixed_float = eFloat;
  //conv_control_params.data_access = eDepthwiseOnly;
  conv_control_params.loop_unroll = eLoopUnroll4;
  //init_conv_control_params(&conv_control_params);
  init_conv_params(&conv_params);
  conv.set_conv_control_params(conv_control_params);
  conv.set_conv_params(conv_params);
  conv_duration = conv.run_convolution();
  cout << "The conv duration is: " << conv_duration << endl;

  //Case4:
  //conv_control_params.fixed_float = eFloat;
  //conv_control_params.data_access = eDepthwiseOnly;
  conv_control_params.loop_unroll = eLoopUnroll8;
  //init_conv_control_params(&conv_control_params);
  init_conv_params(&conv_params);
  conv.set_conv_control_params(conv_control_params);
  conv.set_conv_params(conv_params);
  conv_duration = conv.run_convolution();
  cout << "The conv duration is: " << conv_duration << endl;

  //Case5:
  //conv_control_params.fixed_float = eFloat;
  //conv_control_params.data_access = eDepthwiseOnly;
  conv_control_params.loop_unroll = eLoopUnroll16;
  //init_conv_control_params(&conv_control_params);
  init_conv_params(&conv_params);
  conv.set_conv_control_params(conv_control_params);
  conv.set_conv_params(conv_params);
  conv_duration = conv.run_convolution();
  cout << "The conv duration is: " << conv_duration << endl;

//#endif

#if 0
  Convolution conv;

  double conv_duration;

  ConvParams conv_params;
  ConvControlParams conv_control_params;

  init_conv_control_params(&conv_control_params);
  init_conv_params(&conv_params);

  conv.set_conv_control_params(conv_control_params);
  conv.set_conv_params(conv_params);


  conv_duration = conv.run_convolution();

  cout << "The conv duration is: " << conv_duration << endl;
#endif

  return 0; 
  
}

void init_conv_params(ConvParams *conv_params)
{
  conv_params->inp_h = INP_H;
  conv_params->inp_w = INP_W;
  conv_params->inp_d = INP_D;
  conv_params->ker_h = KER_H;
  conv_params->ker_w = KER_W;
  conv_params->ker_d = INP_D;
  conv_params->dil_h = 1;
  conv_params->dil_w = 1;
  conv_params->nodes = NODES;
  conv_params->str_h = STR_H;
  conv_params->str_w = STR_W;
  conv_params->pad_h = PAD_H;
  conv_params->pad_w = PAD_W;
  conv_params->groups = 1;
  conv_params->flag_bias = 1;
}

void init_conv_control_params(ConvControlParams *conv_control_params)
{
  //to be set by the app
  //conv_control_params->fixed_float = eFixed;
  //conv_control_params->data_access = eDepthwiseKernelReuse;


  ////conv_control_params->dephtwise_planar = eDepthwise;
  ////conv_control_params->data_reuse = eKernelReuse;
  //conv_control_params->loop_unroll = eLoopUnroll16;

  conv_control_params->fixed_float = eFixed;
  conv_control_params->data_access = eDepthwiseKernelReuse;


  //conv_control_params->dephtwise_planar = eDepthwise;
  //conv_control_params->data_reuse = eKernelReuse;
  conv_control_params->loop_unroll = eLoopUnroll4;
}

